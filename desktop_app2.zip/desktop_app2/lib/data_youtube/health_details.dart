
import 'package:desktop_app2/modle_youtube/health_model_youtube.dart';

class HealthDetails {
  final healthData = const [
    HealthModel(
    value: "20", title: "Professors"),
    HealthModel(
    value: "180", title: "Students"),
    HealthModel(
    value: "30", title: "Classes"),
    HealthModel(
    value: "5", title: "Admins"),
  ];
}