import 'package:desktop_app2/modle_youtube/menu_moudel.dart';
import 'package:flutter/material.dart';

class SideMenuData {
  final menu =  <MenuModel>[
    MenuModel(icon: Icons.home, title: 'Dashboard'),
    MenuModel(icon: Icons.person, title: 'Profile'),
    MenuModel(icon: Icons.run_circle, title: 'Exersice'),
    MenuModel(icon: Icons.settings, title: 'Settings'),
    MenuModel(icon: Icons.history, title: 'History'),
    MenuModel(icon: Icons.logout, title: 'SignOut'),
]; // <MenuModel>[]
}