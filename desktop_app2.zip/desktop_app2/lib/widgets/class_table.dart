import 'package:flutter/material.dart';

class ClassTable extends StatelessWidget {
  const ClassTable({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: DataTable(
        columns: const [
          DataColumn(label: Text("Class Name")),
          DataColumn(label: Text("Code")),
          DataColumn(label: Text("Students")),
          DataColumn(label: Text("Room")),
          DataColumn(label: Text("Actions")),
        ],
        rows: List.generate(5, (index) {
          return DataRow(cells: [
            DataCell(Text("Class ${index + 1}")),
            DataCell(Text("C10${index + 1}")),
            DataCell(Text("30")),
            DataCell(Text("Room ${index + 1}")),
            DataCell(Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.blue),
                  onPressed: () {},
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {},
                ),
              ],
            )),
          ]);
        }),
      ),
    );
  }
}
