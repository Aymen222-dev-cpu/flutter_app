/*import 'package:flutter/material.dart';
import '../constants/colors.dart';

class LoginForm extends StatelessWidget {
  const LoginForm({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Text(
          "Login",
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.bold,
            backgroundColor: Colors.white,
          ),
        ),
        const SizedBox(height: 30),
        const InputField(icon: Icons.person, hintText: "User Name"),
        const SizedBox(height: 30),
        const InputField(
          icon: Icons.lock,
          hintText: "Password",
          isPassword: true,
        ),
        const SizedBox(height: 40),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.black,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(25),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 80, vertical: 10),
          ),
          onPressed: () {},
          child: const Text("Login"),
        ),
        const SizedBox(height: 90),
        const Text("welcome to your university"),
      ],
    );
  }
}

class InputField extends StatelessWidget {
  final IconData icon;
  final String hintText;
  final bool isPassword;

  const InputField({
    super.key,
    required this.icon,
    required this.hintText,
    this.isPassword = false,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      obscureText: isPassword,
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: AppColors.black),
        hintText: hintText,
        hintStyle: const TextStyle(color: AppColors.black),
        enabledBorder: const UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.white),
        ),
        focusedBorder: const UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.white),
        ),
      ),
    );
  }
}*/


import 'package:awesome_dialog/awesome_dialog.dart';
import 'dart:async';
import 'package:desktop_app2/screens/dashboard_screen.dart';
import 'package:flutter/material.dart';
import '../constants/colors.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LoginForm extends StatelessWidget {
  const LoginForm({super.key});

  @override
  Widget build(BuildContext context) {
    TextEditingController emailController = TextEditingController();
    TextEditingController passwordController = TextEditingController();
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 8),
          decoration: BoxDecoration(
            color: AppColors.background,
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Text(
            "Login",
            style: TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.bold,
              color: AppColors.black,
            ),
          ),
        ),
        const SizedBox(height: 30),
        InputField(
          icon: Icons.person,
          hintText: "User Name",//------------------------------------------------------------------------------------------
          myController: emailController,
        ),
        const SizedBox(height: 30),
        InputField(
          myController: passwordController,
          icon: Icons.lock,
          hintText: "Password",
          isPassword: true,
        ),
        const SizedBox(height: 40),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.black,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(25),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 80, vertical: 10),
          ),
          onPressed: () async {
            try {
              final credential = await FirebaseAuth.instance
                  .signInWithEmailAndPassword(
                    email: emailController.text,
                    password: passwordController.text,
                  );
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AdminDashboard()),
              );
              AwesomeDialog(
                context: context,
                dialogType: DialogType.success,
                animType: AnimType.rightSlide,
                title: 'Success',
                desc: 'Successfully',
              ).show();
            } on FirebaseAuthException catch (e) {
              if (e.code == 'user-not-found') {
                print('No user found for that email.');
                AwesomeDialog(
                  context: context,
                  dialogType: DialogType.error,
                  animType: AnimType.rightSlide,
                  title: 'Error',
                  desc: 'User not found!',
                ).show();
              } else if (e.code == 'wrong-password') {
                print('Wrong password provided for that user.');
                AwesomeDialog(
                  context: context,
                  dialogType: DialogType.error,
                  animType: AnimType.rightSlide,
                  title: 'Error',
                  desc: 'An error occurred while logging in.',
                ).show();
              }
            }
          },
          child: const Text(
            "Login",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ), // تحسين الزر
          ),
        ),
        const SizedBox(height: 90),
        const Text(
          "welcome to your university",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}

class InputField extends StatelessWidget {
  final IconData icon;
  final String hintText;
  final bool isPassword;
  final TextEditingController myController;
  const InputField({
    super.key,
    required this.icon,
    required this.hintText,
    required this.myController,
    this.isPassword = false,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: myController,
      obscureText: isPassword,
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: AppColors.black),
        labelText: hintText,
        labelStyle: const TextStyle(
          color: AppColors.black,
          fontWeight: FontWeight.bold, // زيادة السمك
        ),
        enabledBorder: const UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 2), // زيادة العرض
        ),
        focusedBorder: const UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 2), // زيادة العرض
        ),
      ),
    );
  }
}
