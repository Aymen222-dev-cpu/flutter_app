import 'package:flutter/material.dart';
import '../constants/colors.dart'; // تأكد من أن الملف يحتوي على AppColors

class PermissionsPage extends StatelessWidget {
  const PermissionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Card(
        color: AppColors.sidebar,
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: const [
                  Icon(Icons.gavel, color: Colors.white, size: 28),
                  SizedBox(width: 10),
                  Text(
                    'Internal Law for Using the System',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const Text(
                '''
It is strictly forbidden to use this system outside the scope of the powers granted to each user. Administrators are only allowed to manage user permissions, create accounts, and control organization-related content. Data privacy must be respected and login information must not be shared with any third party. The system maintains a complete log of all activities for security and auditing purposes.

The user's access to the system constitutes an implicit agreement to abide by these rules, and any violation may lead to disabling the account or taking legal action when necessary.
                ''',
                style: TextStyle(
                  color: Color.fromARGB(232, 255, 255, 255),
                  fontSize: 16,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
