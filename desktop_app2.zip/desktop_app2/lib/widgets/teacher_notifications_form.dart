/*import 'package:flutter/material.dart';

enum NotificationStatus { pending, accepted, rejected }

class NotificationItem {
  final String senderName;
  final String type;
  final String reason;
  final DateTime date;
  final String subject; // المادة
  final String group; // الفوج
  final String field; // التخصص
  final String roomType;

  NotificationStatus status;

  NotificationItem({
    required this.senderName,
    required this.type,
    required this.reason,
    required this.date,
    required this.subject,
    required this.group,
    required this.field,
    required this.roomType,
    this.status = NotificationStatus.pending,
  });
}

class TeacherNoticesPage extends StatefulWidget {
  const TeacherNoticesPage({super.key});

  @override
  State<TeacherNoticesPage> createState() => _TeacherNoticesPageState();
}

class _TeacherNoticesPageState extends State<TeacherNoticesPage> {
  List<NotificationItem> allNotifications = [
    NotificationItem(
      senderName: 'د. سمير الحاج',
      type: 'حصة تعويضية',
      reason: 'كان لدي مؤتمر خارجي وأرغب بتعويض الحصة.',
      date: DateTime.now().subtract(const Duration(days: 1)),
      roomType: 'قاعة إعلام آلي عادية',
      subject: 'برمجة كائنية',
      group: 'الفوج 5',
      field: 'إعلام آلي عادي',
    ),
    NotificationItem(
      senderName: 'أ. ليلى منصور',
      type: 'حصة إضافية',
      reason: 'أرغب بإعطاء حصة مراجعة إضافية قبل الامتحان.',
      date: DateTime.now().subtract(const Duration(hours: 6)),
      roomType: 'قاعة إعلام آلي مدرج',
      subject: 'أنظمة تشغيل',
      group: 'الفوج 3',
      field: 'إعلام آلي عادي',
    ),
    NotificationItem(
      senderName: 'د. سمير الحاج',
      type: 'حصة تعويضية',
      reason: 'كان لدي مؤتمر خارجي وأرغب بتعويض الحصة.',
      date: DateTime.now().subtract(const Duration(days: 1)),
      roomType: 'قاعة إعلام آلي مخبر',
      subject: 'شبكات الحاسوب',
      group: 'الفوج 1',
      field: 'إعلام آلي معمق',
    ),
    NotificationItem(
      senderName: 'أ. ليلى منصور',
      type: 'حصة إضافية',
      reason: 'أرغب بإعطاء حصة مراجعة إضافية قبل الامتحان.',
      date: DateTime.now().subtract(const Duration(hours: 6)),
      roomType: 'قاعة إعلام آلي مدرج',
      subject: 'ذكاء اصطناعي',
      group: 'الفوج 2',
      field: 'إعلام آلي عادي',
    ),
    NotificationItem(
      senderName: 'أ. فاطمة عبد الله',
      type: 'تغيير توقيت',
      reason: 'لدي ظرف طارئ وأرغب بتعديل توقيت الحصة.',
      date: DateTime.now().subtract(const Duration(days: 2)),
      roomType: 'قاعة إعلام آلي عادية',
      subject: 'قواعد البيانات',
      group: 'الفوج 4',
      field: 'إعلام آلي معمق',
    ),
    NotificationItem(
      senderName: 'د. يوسف عمّار',
      type: 'طلب قاعة خاصة',
      reason: 'أحتاج إلى قاعة مزودة بجهاز عرض.',
      date: DateTime.now().subtract(const Duration(days: 3)),
      roomType: 'قاعة إعلام آلي عادية',
      subject: 'ذكاء اصطناعي',
      group: 'الفوج 2',
      field: 'إعلام آلي عادي',
    ),
    NotificationItem(
      senderName: 'أ. منى غريب',
      type: 'إلغاء حصة',
      reason: 'لن أتمكن من الحضور لأسباب صحية.',
      date: DateTime.now().subtract(const Duration(hours: 12)),
      roomType: 'قاعة إعلام آلي مخبر',
      subject: 'ذكاء اصطناعي',
      group: 'الفوج 2',
      field: 'إعلام آلي عادي',
    ),
  ];

  NotificationStatus? filter;

  void showNotificationDialog(NotificationItem notification) {
    final TextEditingController rejectReasonController =
        TextEditingController();
    bool showRejectReason = false;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              title: Text('طلب من ${notification.senderName}'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('📘 النوع: ${notification.type}'),
                  Text('📅 التاريخ: ${notification.date.toLocal()}'),
                  Text('🏫 نوع القاعة: ${notification.roomType}'),
                  const SizedBox(height: 12),
                  Text('📚 المادة: ${notification.subject}'),
                  Text('👥 الفوج: ${notification.group}'),
                  Text('🎓 التخصص: ${notification.field}'),
                  const SizedBox(height: 12),
                  Text('📝 السبب:\n${notification.reason}'),
                  if (showRejectReason) ...[
                    const SizedBox(height: 12),
                    TextField(
                      controller: rejectReasonController,
                      decoration: const InputDecoration(
                        labelText: 'سبب الرفض',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                    ),
                  ],
                ],
              ),
              actions: [
                if (!showRejectReason)
                  TextButton(
                    onPressed: () {
                      setStateDialog(() => showRejectReason = true);
                    },
                    child: const Text(
                      'رفض',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      notification.status = NotificationStatus.accepted;
                    });
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('تم قبول الطلب ✅')),
                    );
                  },
                  child: const Text(
                    'قبول',
                    style: TextStyle(color: Colors.green),
                  ),
                ),
                if (showRejectReason)
                  TextButton(
                    onPressed: () {
                      if (rejectReasonController.text.trim().isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('يرجى كتابة سبب الرفض')),
                        );
                        return;
                      }
                      setState(() {
                        notification.status = NotificationStatus.rejected;
                      });
                      Navigator.of(context).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'تم رفض الطلب مع السبب: ${rejectReasonController.text}',
                          ),
                        ),
                      );
                    },
                    child: const Text(
                      'تأكيد الرفض',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
              ],
            );
          },
        );
      },
    );
  }

  Icon _getStatusIcon(NotificationStatus status) {
    switch (status) {
      case NotificationStatus.accepted:
        return const Icon(Icons.check_circle, color: Colors.green);
      case NotificationStatus.rejected:
        return const Icon(Icons.cancel, color: Colors.red);
      case NotificationStatus.pending:
      default:
        return const Icon(Icons.hourglass_empty, color: Colors.orange);
    }
  }

  @override
  Widget build(BuildContext context) {
    final filteredNotifications =
        filter == null
            ? allNotifications
            : allNotifications.where((n) => n.status == filter).toList();

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "📢 إشعارات الأساتذة",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Text("تصفية حسب الحالة: "),
                const SizedBox(width: 10),
                DropdownButton<NotificationStatus?>(
                  value: filter,
                  items: const [
                    DropdownMenuItem(value: null, child: Text("الكل")),
                    DropdownMenuItem(
                      value: NotificationStatus.pending,
                      child: Text("معلق"),
                    ),
                    DropdownMenuItem(
                      value: NotificationStatus.accepted,
                      child: Text("مقبول"),
                    ),
                    DropdownMenuItem(
                      value: NotificationStatus.rejected,
                      child: Text("مرفوض"),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() {
                      filter = value;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "📢 إشعارات الأساتذة",
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_forever, color: Colors.red),
                  tooltip: 'حذف كل الإشعارات',
                  onPressed: () {
                    if (allNotifications.isEmpty) return;
                    showDialog(
                      context: context,
                      builder:
                          (context) => AlertDialog(
                            title: const Text("تأكيد الحذف"),
                            content: const Text(
                              "هل أنت متأكد أنك تريد حذف كل الإشعارات؟ لا يمكن التراجع.",
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.of(context).pop(),
                                child: const Text("إلغاء"),
                              ),
                              TextButton(
                                onPressed: () {
                                  setState(() {
                                    allNotifications.clear();
                                  });
                                  Navigator.of(context).pop();
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text("تم حذف كل الإشعارات"),
                                    ),
                                  );
                                },
                                child: const Text(
                                  "حذف",
                                  style: TextStyle(color: Colors.red),
                                ),
                              ),
                            ],
                          ),
                    );
                  },
                ),
              ],
            ),

            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: filteredNotifications.length,
              itemBuilder: (context, index) {
                final notif = filteredNotifications[index];
                return Card(
                  elevation: 4,
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
  leading: _getStatusIcon(notif.status),
  title: Text("${notif.senderName} - ${notif.type}"),
  subtitle: Text(
    notif.reason,
    maxLines: 2,
    overflow: TextOverflow.ellipsis,
  ),
  trailing: Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(
        "${notif.date.day}/${notif.date.month}/${notif.date.year}",
        style: TextStyle(color: Colors.grey[600], fontSize: 12),
      ),
      const SizedBox(width: 8),
      IconButton(
        icon: const Icon(Icons.delete, color: Colors.red),
        tooltip: 'حذف هذا الإشعار',
        onPressed: () {
          showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text("تأكيد الحذف"),
              content: const Text("هل أنت متأكد أنك تريد حذف هذا الإشعار؟"),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("إلغاء"),
                ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      allNotifications.removeAt(
                        allNotifications.indexOf(notif),
                      );
                    });
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("تم حذف الإشعار")),
                    );
                  },
                  child: const Text(
                    "حذف",
                    style: TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    ],
  ),
  onTap: () => showNotificationDialog(notif),
),

                 /* child: ListTile(
                    leading: _getStatusIcon(notif.status),
                    title: Text("${notif.senderName} - ${notif.type}"),
                    subtitle: Text(
                      notif.reason,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: Text(
                      "${notif.date.day}/${notif.date.month}/${notif.date.year}",
                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                    ),
                    onTap: () => showNotificationDialog(notif),
                  ),*/
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
بلعربية
*/

import 'package:flutter/material.dart';

enum NotificationStatus { pending, accepted, rejected }

class NotificationItem {
  final String senderName;
  final String type;
  final String reason;
  final DateTime date;
  final String subject; // Subject
  final String group; // Group
  final String field; // Field of study
  final String roomType;

  NotificationStatus status;

  NotificationItem({
    required this.senderName,
    required this.type,
    required this.reason,
    required this.date,
    required this.subject,
    required this.group,
    required this.field,
    required this.roomType,
    this.status = NotificationStatus.pending,
  });
}

class TeacherNoticesPage extends StatefulWidget {
  const TeacherNoticesPage({super.key});

  @override
  State<TeacherNoticesPage> createState() => _TeacherNoticesPageState();
}

class _TeacherNoticesPageState extends State<TeacherNoticesPage> {
  List<NotificationItem> allNotifications = [
    NotificationItem(
      senderName: 'Dr. Samir Al-Hajj',
      type: 'Make-up Session',
      reason: 'I had an external conference and would like to reschedule the session.',
      date: DateTime.now().subtract(const Duration(days: 1)),
      roomType: 'Standard IT Room',
      subject: 'Object-Oriented Programming',
      group: 'Group 5',
      field: 'Standard Computer Science',
    ),
    NotificationItem(
      senderName: 'Ms. Laila Mansour',
      type: 'Extra Session',
      reason: 'I want to give an extra revision session before the exam.',
      date: DateTime.now().subtract(const Duration(hours: 6)),
      roomType: 'Lecture IT Hall',
      subject: 'Operating Systems',
      group: 'Group 3',
      field: 'Standard Computer Science',
    ),
    NotificationItem(
      senderName: 'Dr. Samir Al-Hajj',
      type: 'Make-up Session',
      reason: 'I had an external conference and would like to reschedule the session.',
      date: DateTime.now().subtract(const Duration(days: 1)),
      roomType: 'IT Lab Room',
      subject: 'Computer Networks',
      group: 'Group 1',
      field: 'Advanced Computer Science',
    ),
    NotificationItem(
      senderName: 'Ms. Laila Mansour',
      type: 'Extra Session',
      reason: 'I want to give an extra revision session before the exam.',
      date: DateTime.now().subtract(const Duration(hours: 6)),
      roomType: 'Lecture IT Hall',
      subject: 'Artificial Intelligence',
      group: 'Group 2',
      field: 'Standard Computer Science',
    ),
    NotificationItem(
      senderName: 'Ms. Fatima Abdullah',
      type: 'Time Change',
      reason: 'I have an urgent matter and would like to reschedule the session time.',
      date: DateTime.now().subtract(const Duration(days: 2)),
      roomType: 'Standard IT Room',
      subject: 'Databases',
      group: 'Group 4',
      field: 'Advanced Computer Science',
    ),
    NotificationItem(
      senderName: 'Dr. Youssef Ammar',
      type: 'Special Room Request',
      reason: 'I need a room equipped with a projector.',
      date: DateTime.now().subtract(const Duration(days: 3)),
      roomType: 'Standard IT Room',
      subject: 'Artificial Intelligence',
      group: 'Group 2',
      field: 'Standard Computer Science',
    ),
    NotificationItem(
      senderName: 'Ms. Mona Ghareeb',
      type: 'Session Cancellation',
      reason: 'I will not be able to attend due to health reasons.',
      date: DateTime.now().subtract(const Duration(hours: 12)),
      roomType: 'IT Lab Room',
      subject: 'Artificial Intelligence',
      group: 'Group 2',
      field: 'Standard Computer Science',
    ),
  ];

  NotificationStatus? filter;

  void showNotificationDialog(NotificationItem notification) {
    final TextEditingController rejectReasonController = TextEditingController();
    bool showRejectReason = false;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              title: Text('Request from ${notification.senderName}'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('📘 Type: ${notification.type}'),
                  Text('📅 Date: ${notification.date.toLocal()}'),
                  Text('🏫 Room Type: ${notification.roomType}'),
                  const SizedBox(height: 12),
                  Text('📚 Subject: ${notification.subject}'),
                  Text('👥 Group: ${notification.group}'),
                  Text('🎓 Field: ${notification.field}'),
                  const SizedBox(height: 12),
                  Text('📝 Reason:\n${notification.reason}'),
                  if (showRejectReason) ...[
                    const SizedBox(height: 12),
                    TextField(
                      controller: rejectReasonController,
                      decoration: const InputDecoration(
                        labelText: 'Rejection Reason',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                    ),
                  ],
                ],
              ),
              actions: [
                if (!showRejectReason)
                  TextButton(
                    onPressed: () {
                      setStateDialog(() => showRejectReason = true);
                    },
                    child: const Text(
                      'Reject',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      notification.status = NotificationStatus.accepted;
                    });
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Request accepted ✅')),
                    );
                  },
                  child: const Text(
                    'Accept',
                    style: TextStyle(color: Colors.green),
                  ),
                ),
                if (showRejectReason)
                  TextButton(
                    onPressed: () {
                      if (rejectReasonController.text.trim().isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Please enter a rejection reason')),
                        );
                        return;
                      }
                      setState(() {
                        notification.status = NotificationStatus.rejected;
                      });
                      Navigator.of(context).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Request rejected with reason: ${rejectReasonController.text}',
                          ),
                        ),
                      );
                    },
                    child: const Text(
                      'Confirm Rejection',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
              ],
            );
          },
        );
      },
    );
  }

  Icon _getStatusIcon(NotificationStatus status) {
    switch (status) {
      case NotificationStatus.accepted:
        return const Icon(Icons.check_circle, color: Colors.green);
      case NotificationStatus.rejected:
        return const Icon(Icons.cancel, color: Colors.red);
      case NotificationStatus.pending:
      default:
        return const Icon(Icons.hourglass_empty, color: Colors.orange);
    }
  }

  @override
  Widget build(BuildContext context) {
    final filteredNotifications =
        filter == null ? allNotifications : allNotifications.where((n) => n.status == filter).toList();

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "📢 Teachers' Notifications",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Text("Filter by status: "),
                const SizedBox(width: 10),
                DropdownButton<NotificationStatus?>(
                  value: filter,
                  items: const [
                    DropdownMenuItem(value: null, child: Text("All")),
                    DropdownMenuItem(value: NotificationStatus.pending, child: Text("Pending")),
                    DropdownMenuItem(value: NotificationStatus.accepted, child: Text("Accepted")),
                    DropdownMenuItem(value: NotificationStatus.rejected, child: Text("Rejected")),
                  ],
                  onChanged: (value) {
                    setState(() {
                      filter = value;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "📢 Teachers' Notifications",
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_forever, color: Colors.red),
                  tooltip: 'Delete all notifications',
                  onPressed: () {
                    if (allNotifications.isEmpty) return;
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text("Confirm Deletion"),
                        content: const Text(
                          "Are you sure you want to delete all notifications? This action cannot be undone.",
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.of(context).pop(),
                            child: const Text("Cancel"),
                          ),
                          TextButton(
                            onPressed: () {
                              setState(() {
                                allNotifications.clear();
                              });
                              Navigator.of(context).pop();
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text("All notifications deleted")),
                              );
                            },
                            child: const Text(
                              "Delete",
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: filteredNotifications.length,
              itemBuilder: (context, index) {
                final notif = filteredNotifications[index];
                return Card(
                  elevation: 4,
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    leading: _getStatusIcon(notif.status),
                    title: Text("${notif.senderName} - ${notif.type}"),
                    subtitle: Text(
                      notif.reason,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "${notif.date.day}/${notif.date.month}/${notif.date.year}",
                          style: TextStyle(color: Colors.grey[600], fontSize: 12),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          tooltip: 'Delete this notification',
                          onPressed: () {
                            showDialog(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: const Text("Confirm Deletion"),
                                content: const Text("Are you sure you want to delete this notification?"),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context),
                                    child: const Text("Cancel"),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      setState(() {
                                        allNotifications.removeAt(allNotifications.indexOf(notif));
                                      });
                                      Navigator.pop(context);
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text("Notification deleted")),
                                      );
                                    },
                                    child: const Text(
                                      "Delete",
                                      style: TextStyle(color: Colors.red),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                    onTap: () => showNotificationDialog(notif),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
