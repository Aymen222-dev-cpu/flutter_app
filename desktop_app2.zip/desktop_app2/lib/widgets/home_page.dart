import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Home",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        Card(
          elevation: 8,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Row(
                  children: [
                    Icon(Icons.info_outline, size: 28, color: Colors.blueAccent),
                    SizedBox(width: 10),
                    Text(
                      "System Overview",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Text(
                  "Abstract",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  "With the rapid advancement of technology, digital systems are increasingly being adopted to streamline administrative and educational processes in higher education institutions.",
                  style: TextStyle(fontSize: 16, color: Colors.black87, height: 1.4),
                ),  
                SizedBox(height: 10),
                Text(
                  "This application is designed to automate and optimize the scheduling of pedagogical activities at the FNTIC faculty, as well as course and event management. By reducing manual errors and enhancing oversight, it ensures a more efficient and controlled workflow.",
                  style: TextStyle(fontSize: 16, color: Colors.black87, height: 1.4),
                ),
                SizedBox(height: 10),
                Text(
                  "As an integrated system, it provides faculty and administrators with a user-friendly interface to:\n\n"
                  "• Easily input and manage courses and events with minimal effort.\n"
                  "• Minimize scheduling errors common in manual planning.\n"
                  "• Centralize coordination for seamless collaboration.\n"
                  "• Adapt flexibly to the faculty’s specific needs and requirements.",
                  style: TextStyle(fontSize: 16, color: Colors.black87, height: 1.5),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
