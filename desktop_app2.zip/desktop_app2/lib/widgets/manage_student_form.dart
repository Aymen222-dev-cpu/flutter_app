import 'package:flutter/material.dart';

class ManageStudentsScreen extends StatelessWidget {
  const ManageStudentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // بيانات وهمية - يمكنك استبدالها ببيانات فعلية من Firebase أو API
    final List<Map<String, String>> students = [
      {
        "name": "Ali Benali",
        "email": "ali@student.dz",
        "level": "L3",
        "group": "G1",
      },
      {
        "name": "Sara Bouchareb",
        "email": "sara@student.dz",
        "level": "M1",
        "group": "G2",
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Manage Students",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),

        // 🔍 شريط البحث
        TextField(
          decoration: InputDecoration(
            hintText: "Search by name or email...",
            prefixIcon: const Icon(Icons.search),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
        const SizedBox(height: 20),

        // 📋 الجدول
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: const [
              DataColumn(label: Text("Name")),
              DataColumn(label: Text("Email")),
              DataColumn(label: Text("Level")),
              DataColumn(label: Text("Group")), // 🆕 عمود جديد
              DataColumn(label: Text("Actions")),
            ],
            rows:
                students.map((student) {
                  return DataRow(
                    cells: [
                      DataCell(Text(student["name"]!)),
                      DataCell(Text(student["email"]!)),
                      DataCell(Text(student["level"]!)),
                      DataCell(Text(student["group"]!)), // 🆕 بيانات المجموعة
                      DataCell(
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: Colors.blue),
                              onPressed: () {
                                // TODO: فتح نافذة تعديل البيانات
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () {
                                // TODO: تأكيد وحذف الطالب
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                }).toList(),
          ),
        ),
      ],
    );
  }
}
