import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddStudentForm extends StatelessWidget {
  AddStudentForm({super.key});

  final TextEditingController fullNameController = TextEditingController();
  final TextEditingController specializationController =
      TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController registrationNumberController =
      TextEditingController();
  final TextEditingController sectionController = TextEditingController();
  final TextEditingController telephoneNumberController =
      TextEditingController();
  final TextEditingController groupController =
      TextEditingController(); // Added controller

  Future<void> saveStudentData() async {
    try {
      await FirebaseFirestore.instance.collection('users').add({
        'full_name': fullNameController.text,
        'role': 'Student',
        'specialization': specializationController.text,
        'email': emailController.text,
        'password': registrationNumberController.text,
        'section': sectionController.text,
        'phone': telephoneNumberController.text,
        'group': groupController.text, // Added group field
      });
      print("Student data saved successfully!");
    } catch (e) {
      print("Error saving student data: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(4, 4)),
        ],
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Add Student",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Wrap(
              spacing: 20,
              runSpacing: 15,
              children: [
                SizedBox(
                  width: 300,
                  child: TextField(
                    controller: fullNameController,
                    decoration: const InputDecoration(labelText: "Full Name"),
                  ),
                ),
                SizedBox(
                  width: 300,
                  child: TextField(
                    controller: specializationController,
                    decoration: const InputDecoration(
                      labelText: "Specialization",
                    ),
                  ),
                ),
                SizedBox(
                  width: 300,
                  child: TextField(
                    controller: emailController,
                    decoration: const InputDecoration(labelText: "Email"),
                  ),
                ),
                SizedBox(
                  width: 300,
                  child: TextField(
                    controller: registrationNumberController,
                    decoration: const InputDecoration(
                      labelText: "Registration Number",
                    ),
                  ),
                ),
                SizedBox(
                  width: 300,
                  child: TextField(
                    controller: sectionController,
                    decoration: const InputDecoration(labelText: "Section"),
                  ),
                ),
                SizedBox(
                  width: 300,
                  child: TextField(
                    controller: telephoneNumberController,
                    decoration: const InputDecoration(
                      labelText: "Telephone Number",
                    ),
                  ),
                ),
                SizedBox(
                  width: 300,
                  child: TextField(
                    controller: groupController,
                    decoration: const InputDecoration(labelText: "Group"),
                  ),
                ), // Added group field
              ],
            ),
            const SizedBox(height: 25),
            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                ),
                onPressed: () async {
                  await saveStudentData();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Student data saved successfully!"),
                    ),
                  );
                },
                child: const Text(
                  "Save",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
