import 'package:flutter/material.dart';

class SubjectsManager extends StatefulWidget {
  const SubjectsManager({super.key});

  @override
  State<SubjectsManager> createState() => _SubjectsManagerState();
}

class _SubjectsManagerState extends State<SubjectsManager> {
  final TextEditingController _subjectNameController = TextEditingController();
  final List<String> _subjects = [];

  void _addSubject() {
    final name = _subjectNameController.text.trim();
    if (name.isNotEmpty && !_subjects.contains(name)) {
      setState(() {
        _subjects.add(name);
        _subjectNameController.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Manage Subjects", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _subjectNameController,
                decoration: const InputDecoration(
                  labelText: 'Subject Name',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(width: 10),
            ElevatedButton(
              onPressed: _addSubject,
              child: const Text("Add"),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const Text("Subjects List:"),
        const SizedBox(height: 10),
        ..._subjects.map((s) => ListTile(
              leading: const Icon(Icons.book),
              title: Text(s),
            )),
      ],
    );
  }
}
