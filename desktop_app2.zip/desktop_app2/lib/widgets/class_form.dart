import 'package:flutter/material.dart';

class ClassForm extends StatelessWidget {
  const ClassForm({super.key});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 20,
      runSpacing: 15,
      children: const [
        SizedBox(
          width: 250,
          child: TextField(
            decoration: InputDecoration(labelText: "Class Name"),
          ),
        ),
        SizedBox(
          width: 250,
          child: TextField(
            decoration: InputDecoration(labelText: "Class Code"),
          ),
        ),
        SizedBox(
          width: 250,
          child: TextField(
            decoration: InputDecoration(labelText: "Number of Students"),
          ),
        ),
        SizedBox(
          width: 250,
          child: TextField(
            decoration: InputDecoration(labelText: "Room"),
          ),
        ),
        SizedBox(
          height: 50,
          child: ElevatedButton(
            onPressed: null, // Add logic here
            child: Text("Add Class"),
          ),
        ),
      ],
    );
  }
}
