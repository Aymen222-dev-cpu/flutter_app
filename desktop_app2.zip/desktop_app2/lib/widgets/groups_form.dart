/*import 'package:flutter/material.dart';

class GroupsManager extends StatefulWidget {
  const GroupsManager({super.key});

  @override
  State<GroupsManager> createState() => _GroupsManagerState();
}

class _GroupsManagerState extends State<GroupsManager> {
  final TextEditingController _groupNameController = TextEditingController();
  final List<String> _groups = [];

  void _addGroup() {
    final name = _groupNameController.text.trim();
    if (name.isNotEmpty && !_groups.contains(name)) {
      setState(() {
        _groups.add(name);
        _groupNameController.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Manage Groups", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _groupNameController,
                decoration: const InputDecoration(
                  labelText: 'Group Name',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(width: 10),
            ElevatedButton(
              onPressed: _addGroup,
              child: const Text("Add"),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const Text("Existing Groups:"),
        const SizedBox(height: 10),
        ..._groups.map((g) => ListTile(
              leading: const Icon(Icons.group),
              title: Text(g),
            )),
      ],
    );
  }
}
*/
import 'package:flutter/material.dart';

class GroupsManager extends StatefulWidget {
  const GroupsManager({super.key});

  @override
  State<GroupsManager> createState() => _GroupsManagerState();
}

class _GroupsManagerState extends State<GroupsManager> {
  final TextEditingController _groupNameController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();
  final List<Map<String, dynamic>> _groups = [];
  String? _editingGroupId;
  final TextEditingController _editGroupController = TextEditingController();
  String? _selectedGroup;
  String _searchQuery = '';
  bool _showStudentsList = false;

  @override
  void dispose() {
    _groupNameController.dispose();
    _searchController.dispose();
    _editGroupController.dispose();
    super.dispose();
  }

  void _addGroup() {
    final name = _groupNameController.text.trim();
    if (name.isNotEmpty && !_groups.any((g) => g['name'] == name)) {
      setState(() {
        _groups.add({
          'id': DateTime.now().toString(),
          'name': name,
          'students': List.generate(5, (index) => 'Student ${index + 1}'), // طلاب افتراضيين
          'year': '2023-2024',
        });
        _groupNameController.clear();
      });
    }
  }

  void _deleteGroup(String id) {
    setState(() {
      _groups.removeWhere((g) => g['id'] == id);
      if (_selectedGroup == id) {
        _selectedGroup = null;
        _showStudentsList = false;
      }
    });
  }

  void _startEditingGroup(Map<String, dynamic> group) {
    _editingGroupId = group['id'];
    _editGroupController.text = group['name'];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Group'),
        content: TextField(
          controller: _editGroupController,
          decoration: const InputDecoration(labelText: 'Group Name'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (_editGroupController.text.trim().isNotEmpty) {
                setState(() {
                  _groups.firstWhere((g) => g['id'] == _editingGroupId)['name'] =
                      _editGroupController.text.trim();
                  _editingGroupId = null;
                  _editGroupController.clear();
                });
                Navigator.pop(context);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _addStudentToGroup(String groupId) {
    setState(() {
      final group = _groups.firstWhere((g) => g['id'] == groupId);
      group['students'].add('Student ${group['students'].length + 1}');
    });
  }

  void _removeStudentFromGroup(String groupId, int index) {
    setState(() {
      _groups.firstWhere((g) => g['id'] == groupId)['students'].removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    final filteredStudents = _selectedGroup != null
        ? _groups
            .firstWhere((g) => g['id'] == _selectedGroup)['students']
            .where((student) => student
                .toLowerCase()
                .contains(_searchQuery.toLowerCase()))
            .toList()
        : [];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_showStudentsList) ...[
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () {
                  setState(() {
                    _showStudentsList = false;
                    _searchQuery = '';
                    _searchController.clear();
                  });
                },
              ),
              Text(
                _groups.firstWhere((g) => g['id'] == _selectedGroup)['name'],
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    labelText: 'Search students',
                    prefixIcon: const Icon(Icons.search),
                    border: const OutlineInputBorder(),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              setState(() {
                                _searchQuery = '';
                                _searchController.clear();
                              });
                            },
                          )
                        : null,
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                ),
                const SizedBox(height: 10),
                ...filteredStudents.asMap().entries.map((entry) => ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(entry.value),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _removeStudentFromGroup(_selectedGroup!, entry.key),
                  ),
                )),
                const SizedBox(height: 10),
                ElevatedButton.icon(
                  icon: const Icon(Icons.add),
                  label: const Text("Add Student"),
                  onPressed: () => _addStudentToGroup(_selectedGroup!),
                ),
              ],
            ),
          ),
        ] else ...[
          const Text(
            "Manage Groups",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _groupNameController,
                  decoration: const InputDecoration(
                    labelText: 'Group Name',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: _addGroup,
                child: const Text("Add Group"),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const Text("Existing Groups:", style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ..._groups.map((group) => Card(
            margin: const EdgeInsets.symmetric(vertical: 4),
            child: ListTile(
              leading: const Icon(Icons.group),
              title: Text(group['name']),
              subtitle: Text('Year: ${group['year']} • Students: ${group['students'].length}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit, size: 20),
                    onPressed: () => _startEditingGroup(group),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                    onPressed: () => _deleteGroup(group['id']),
                  ),
                  IconButton(
                    icon: const Icon(Icons.arrow_forward, size: 20),
                    onPressed: () {
                      setState(() {
                        _selectedGroup = group['id'];
                        _showStudentsList = true;
                      });
                    },
                  ),
                ],
              ),
            ),
          )),
        ],
      ],
    );
  }
}