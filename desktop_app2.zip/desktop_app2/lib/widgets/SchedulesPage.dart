import 'package:desktop_app2/constants/colors.dart';
import 'package:flutter/material.dart';

class ScheduleTable {
  final String title;
  final String group;
  final String section;
  final String year;

  const ScheduleTable({
    required this.title,
    required this.group,
    required this.section,
    required this.year,
  });
}

class SchedulesPage extends StatelessWidget {
  final List<ScheduleTable> tables;

  const SchedulesPage({
    Key? key,
    this.tables = const [
      const ScheduleTable(
        title: "Programming",
        group: "G1",
        section: "S1",
        year: "2023",
      ),
      const ScheduleTable(
        title: "Networks",
        group: "G2",
        section: "S2",
        year: "2024",
      ),
    ],
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Schedules",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            // Search Field
            Expanded(
              child: TextField(
                decoration: InputDecoration(
                  hintText: "Search",
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            // PDF Import Button
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              onPressed: () {
                // PDF import logic
              },
              icon: const Icon(Icons.picture_as_pdf),
              label: const Text("Add from PDF"),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Wrap(
          spacing: 16,
          runSpacing: 16,
          children:
              tables.map((table) {
                return SizedBox(
                  width: 180,
                  child: Card(
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 12,
                        horizontal: 8,
                      ),
                      child: Column(
                        children: [
                          const Icon(
                            Icons.table_chart,
                            size: 40,
                            color: Colors.teal,
                          ),
                          const SizedBox(height: 10),
                          Text(
                            table.title,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text("Group: ${table.group}"),
                          Text("Section: ${table.section}"),
                          Text(table.year),
                          const SizedBox(height: 10),
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.teal[300],
                              shape: const StadiumBorder(),
                              minimumSize: const Size.fromHeight(30),
                            ),
                            onPressed: () {
                              // Add session logic
                            },
                            icon: const Icon(Icons.edit, size: 16),
                            label: const Text("Modify"),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
        ),
        const SizedBox(height: 50),
        Align(
          alignment: Alignment.bottomRight,
          child: FloatingActionButton(
            backgroundColor: Colors.teal,
            onPressed: () {
              // Add new schedule logic
            },
            child: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }
}
