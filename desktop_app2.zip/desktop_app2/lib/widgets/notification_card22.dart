import 'package:flutter/material.dart';
import 'package:desktop_app2/constants/colors.dart';

class NotificationsPages extends StatefulWidget {
  const NotificationsPages({super.key});

  @override
  State<NotificationsPages> createState() => _NotificationsPage22State();
}

class _NotificationsPage22State extends State<NotificationsPages> {
  final List<Map<String, dynamic>> notifications = [
    {
      'id': '1',
      'sender': 'الطالب: أحمد محمد',
      'type': 'حصة تعويضية',
      'date': '2023-05-20 10:30',
      'status': 'pending',
      'reason': 'لدي امتحان في نفس وقت الحصة وأحتاج إلى حصة تعويضية',
    },
    {
      'id': '2',
      'sender': 'الأستاذ: خالد عبدالله',
      'type': 'حصة إضافية',
      'date': '2023-05-19 14:15',
      'status': 'pending',
      'reason': 'أرغب في تقديم حصة إضافية لشرح موضوع إضافي',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.all(0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'الإشعارات الواردة',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: notifications.length,
                itemBuilder: (context, index) {
                  final notification = notifications[index];
                  return NotificationItem(
                    notification: notification,
                    onTap: () => _showNotificationDetails(context, notification),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showNotificationDetails(BuildContext context, Map<String, dynamic> notification) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('تفاصيل الطلب - ${notification['type']}'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('المرسل: ${notification['sender']}'),
                const SizedBox(height: 10),
                Text('التاريخ: ${notification['date']}'),
                const SizedBox(height: 10),
                const Text('السبب:', style: TextStyle(fontWeight: FontWeight.bold)),
                Text(notification['reason']),
                const SizedBox(height: 20),
                if (notification['status'] == 'pending')
                  _buildActionButtons(context, notification),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('إغلاق'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildActionButtons(BuildContext context, Map<String, dynamic> notification) {
    TextEditingController reasonController = TextEditingController();

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                _updateNotificationStatus(notification['id'], 'accepted');
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('تم قبول طلب ${notification['type']}'),
                    backgroundColor: Colors.green,
                  ),
                );
              },
              child: const Text('قبول'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: const Text('سبب الرفض'),
                      content: TextField(
                        controller: reasonController,
                        decoration: const InputDecoration(
                          hintText: 'أدخل سبب رفض الطلب...',
                          border: OutlineInputBorder(),
                        ),
                        maxLines: 3,
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.of(context).pop(),
                          child: const Text('إلغاء'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            if (reasonController.text.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('الرجاء إدخال سبب الرفض'),
                                  backgroundColor: Colors.red,
                                ),
                              );
                              return;
                            }
                            _updateNotificationStatus(
                              notification['id'], 
                              'rejected',
                              rejectionReason: reasonController.text,
                            );
                            Navigator.of(context)
                              ..pop()
                              ..pop();
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('تم رفض طلب ${notification['type']}'),
                                backgroundColor: Colors.red,
                              ),
                            );
                          },
                          child: const Text('تأكيد الرفض'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: const Text('رفض'),
            ),
          ],
        ),
      ],
    );
  }

  void _updateNotificationStatus(String id, String status, {String? rejectionReason}) {
    setState(() {
      final index = notifications.indexWhere((n) => n['id'] == id);
      if (index != -1) {
        notifications[index]['status'] = status;
        if (rejectionReason != null) {
          notifications[index]['rejectionReason'] = rejectionReason;
        }
      }
    });
  }
}

class NotificationItem extends StatelessWidget {
  final Map<String, dynamic> notification;
  final VoidCallback onTap;

  const NotificationItem({
    super.key,
    required this.notification,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Color statusColor = Colors.grey;
    IconData statusIcon = Icons.access_time;

    switch (notification['status']) {
      case 'accepted':
        statusColor = Colors.green;
        statusIcon = Icons.check_circle;
        break;
      case 'rejected':
        statusColor = Colors.red;
        statusIcon = Icons.cancel;
        break;
      default:
        statusColor = Colors.orange;
        statusIcon = Icons.pending;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: Icon(statusIcon, color: statusColor),
        title: Text(notification['sender']),
        subtitle: Text('${notification['type']} - ${notification['date']}'),
        trailing: const Icon(Icons.arrow_forward_ios),
        onTap: onTap,
      ),
    );
  }
}