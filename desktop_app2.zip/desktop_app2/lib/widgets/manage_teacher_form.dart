import 'package:flutter/material.dart';

class ManageTeachersScreen extends StatelessWidget {
  const ManageTeachersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // بيانات وهمية - يمكنك استبدالها ببيانات فعلية من Firebase أو API
    final List<Map<String, String>> teachers = [
      {"name": "Dr. Ahmed", "email": "ahmed@univ.dz", "subject": "Math"},
      {"name": "Mme. Laila", "email": "laila@univ.dz", "subject": "Physics"},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Manage Teachers",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),

        // 🔍 شريط البحث
        TextField(
          decoration: InputDecoration(
            hintText: "Search by name or email...",
            prefixIcon: const Icon(Icons.search),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
        const SizedBox(height: 20),

        // 📋 الجدول
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: const [
              DataColumn(label: Text("Name")),
              DataColumn(label: Text("Email")),
              DataColumn(label: Text("Subject")),
              DataColumn(label: Text("Actions")),
            ],
            rows: teachers.map((teacher) {
              return DataRow(cells: [
                DataCell(Text(teacher["name"]!)),
                DataCell(Text(teacher["email"]!)),
                DataCell(Text(teacher["subject"]!)),
                DataCell(Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed: () {
                        // TODO: فتح نافذة تعديل البيانات
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        // TODO: تأكيد وحذف الأستاذ
                      },
                    ),
                  ],
                )),
              ]);
            }).toList(),
          ),
        ),
      ],
    );
  }
}
