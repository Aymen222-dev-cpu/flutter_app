/*import 'package:flutter/material.dart';
import '../constants/colors.dart';

class Sidebar extends StatefulWidget {
  const Sidebar({super.key});

  @override
  State<Sidebar> createState() => _SidebarState();
}

class _SidebarState extends State<Sidebar> {
  bool isCollapsed = false;

  @override
  Widget build(BuildContext context) {
    // تصغير الشريط تلقائياً على الشاشات الصغيرة

    double sidebarWidth = isCollapsed ? 80 : 250;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: sidebarWidth,
      padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 15),
      decoration: const BoxDecoration(
        color: AppColors.sidebar,
        boxShadow: [
          BoxShadow(color: Colors.black26, blurRadius: 8, offset: Offset(2, 4)),
        ],
      ),
      child: Column(
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: IconButton(
              icon: Icon(
                isCollapsed ? Icons.arrow_forward_ios : Icons.arrow_back_ios,
                color: AppColors.background,
              ),
              onPressed: () {
                setState(() {
                  isCollapsed = !isCollapsed;
                });
              },
            ),
          ),
          const SizedBox(height: 10),
          CircleAvatar(
            radius: 30,
            backgroundColor: AppColors.background,
            child: Icon(Icons.person, size: 30, color: AppColors.sidebar),
          ),
          if (!isCollapsed) ...[
            const SizedBox(height: 10),
            const Text(
              "Administrator",
              style: TextStyle(
                color: AppColors.background,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            const Text(
              "University Orange",
              style: TextStyle(color: AppColors.background, fontSize: 12),
            ),
            const SizedBox(height: 30),
          ],
          buildMenuItem(Icons.home, "Home"),
          buildMenuItem(Icons.admin_panel_settings, "Admin"),
          buildMenuItem(Icons.person, "Teacher"),
          buildMenuItem(Icons.school, "Student"),
          /*buildMenuItem(Icons.class_, "Class"),*/
          buildMenuItem(
            Icons.class_,
            "Class",
            onTap: () {
              Navigator.pushNamed(context, '/classes');
            },
          ),

          buildMenuItem(Icons.schedule, "Schedule"),
          buildMenuItem(Icons.bar_chart, "Statistics"),
          buildMenuItem(Icons.notifications, "Notifications"),
          const Spacer(),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.background,
              foregroundColor: AppColors.sidebar,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              padding:
                  isCollapsed
                      ? const EdgeInsets.all(8)
                      : const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 10,
                      ),
            ),
            child:
                isCollapsed
                    ? const Icon(Icons.logout, size: 18)
                    : const Text("Logout"),
          ),
        ],
      ),
    );
  }

  Widget buildMenuItem(IconData icon, String label, {VoidCallback? onTap}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: InkWell(
        onTap: onTap,
        child: Row(
          children: [
            Icon(icon, color: AppColors.background),
            const SizedBox(width: 10),
            Text(label, style: const TextStyle(color: AppColors.background)),
          ],
        ),
      ),
    );
  }
}
// قبل اضافة العناوين الفرعية */
//
/*
import 'package:desktop_app2/screens/login_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../constants/colors.dart';

class Sidebar extends StatefulWidget {
  const Sidebar({super.key});

  @override
  State<Sidebar> createState() => _SidebarState();
}

class _SidebarState extends State<Sidebar> {
  bool isCollapsed = false;
  String activeMenu = "Home";
  String? expandedMenu;

  double get sidebarWidth => isCollapsed ? 80 : 250;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          width: sidebarWidth,
          padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 15),
          decoration: const BoxDecoration(
            color: AppColors.sidebar,
            boxShadow: [
              BoxShadow(
                color: Colors.black26,
                blurRadius: 8,
                offset: Offset(2, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              // زر الطي مع معلومات المستخدم
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  IconButton(
                    icon: Icon(
                      isCollapsed
                          ? Icons.arrow_forward_ios
                          : Icons.arrow_back_ios,
                      color: AppColors.background,
                    ),
                    onPressed: () => setState(() => isCollapsed = !isCollapsed),
                  ),
                  if (!isCollapsed) ...[
                    const SizedBox(width: 10),
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: AppColors.background,
                      child: Icon(
                        Icons.person,
                        size: 20,
                        color: AppColors.sidebar,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            "Administrator",
                            style: TextStyle(
                              color: AppColors.background,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            "University Orange",
                            style: TextStyle(
                              color: AppColors.background,
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 20),

              // القائمة القابلة للتمرير
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      buildExpandableMenu("Home", Icons.home),
                      buildExpandableMenu(
                        "Admin",
                        Icons.admin_panel_settings,
                        children: ["Roles", "Permissions"],
                      ),
                      buildExpandableMenu(
                        "Teacher",
                        Icons.person,
                        children: ["Add Teacher", "Manage Teachers"],
                      ),
                      buildExpandableMenu(
                        "Student",
                        Icons.school,
                        children: ["Add Student", "Manage Students"],
                      ),
                      buildExpandableMenu(
                        "Class",
                        Icons.class_,
                        children: ["Groups", "Subjects"],
                        route: '/classes',
                      ),
                      buildMenuItem("Schedule", Icons.schedule),
                      buildMenuItem("Statistics", Icons.bar_chart),
                      buildMenuItem("Notifications", Icons.notifications),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),

              // زر الخروج دائمًا في الأسفل
              Align(
                alignment: Alignment.bottomCenter,
                child: buildLogoutButton(),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget buildCollapseButton() {
    return Align(
      alignment: Alignment.centerLeft,
      child: IconButton(
        icon: Icon(
          isCollapsed ? Icons.arrow_forward_ios : Icons.arrow_back_ios,
          color: AppColors.background,
        ),
        onPressed: () => setState(() => isCollapsed = !isCollapsed),
      ),
    );
  }

  Widget buildUserInfo() {
    return Column(
      children: [
        CircleAvatar(
          radius: 30,
          backgroundColor: AppColors.background,
          child: Icon(Icons.person, size: 30, color: AppColors.sidebar),
        ),
        if (!isCollapsed) ...[
          const SizedBox(height: 10),
          const Text(
            "Administrator",
            style: TextStyle(
              color: AppColors.background,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const Text(
            "University Orange",
            style: TextStyle(color: AppColors.background, fontSize: 12),
          ),
        ],
      ],
    );
  }

  Widget buildExpandableMenu(
    String label,
    IconData icon, {
    List<String> children = const [],
    String? route,
  }) {
    final isExpanded = expandedMenu == label;
    final isActive = activeMenu == label;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: () {
            setState(() {
              activeMenu = label;
              expandedMenu = isExpanded ? null : label;
              if (route != null) {
                Navigator.pushNamed(context, route);
              }
            });
          },
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            decoration: BoxDecoration(
              color: isActive ? Colors.black26 : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                Icon(icon, color: AppColors.background),
                if (!isCollapsed) ...[
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      label,
                      style: const TextStyle(color: AppColors.background),
                    ),
                  ),
                  Icon(
                    isExpanded
                        ? Icons.keyboard_arrow_up
                        : Icons.keyboard_arrow_down,
                    color: AppColors.background,
                  ),
                ],
              ],
            ),
          ),
        ),
        if (!isCollapsed && isExpanded)
          Padding(
            padding: const EdgeInsets.only(left: 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children:
                  children.map((subItem) {
                    return InkWell(
                      onTap: () {
                        setState(() => activeMenu = subItem);
                        // يمكنك إضافة تنقل هنا إن أردت
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: Text(
                          "- $subItem",
                          style: const TextStyle(color: Colors.white70),
                        ),
                      ),
                    );
                  }).toList(),
            ),
          ),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget buildMenuItem(String label, IconData icon) {
    final isActive = activeMenu == label;

    return InkWell(
      onTap:
          () => setState(() {
            activeMenu = label;
            expandedMenu = null;
          }),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          color: isActive ? Colors.black26 : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppColors.background),
            if (!isCollapsed) ...[
              const SizedBox(width: 10),
              Text(label, style: const TextStyle(color: AppColors.background)),
            ],
          ],
        ),
      ),
    );
  }

  Widget buildLogoutButton() {
    return ElevatedButton(
      onPressed: () {},
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.sidebar,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        padding:
            isCollapsed
                ? const EdgeInsets.all(8)
                : const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      ),
      child:
          isCollapsed
              ? const Icon(Icons.logout, size: 18)
              : ElevatedButton(
                onPressed: () async {
                  await FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => LoginScreen()),
                  );
                },
                child: const Text("Logout"),
              ),
      // : const Text("Logout"),
    );
  }
}
// قبل اضافة تنقل الصفحات
*/

import 'package:desktop_app2/screens/login_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../constants/colors.dart';

class Sidebar extends StatefulWidget {
  final Function(String) onItemSelected;

  const Sidebar({super.key, required this.onItemSelected});

  @override
  State<Sidebar> createState() => _SidebarState();
}

class _SidebarState extends State<Sidebar> {
  bool isCollapsed = false;
  String activeMenu = "Home";
  String? expandedMenu;

  double get sidebarWidth => isCollapsed ? 80 : 250;

  String _normalizeLabel(String label) {
    switch (label.toLowerCase()) {
      case 'home':
        return 'home';
      case 'add teacher':
        return 'add_teacher';
      case 'manage teachers':
        return 'manage_teachers';
      case 'add student':
        return 'add_student';
      case 'manage students':
        return 'manage_students';
      case 'profile':
        return 'Profile_form';
      case 'permissions':
        return 'permissions_page';
      case 'groups':
        return 'groups';
      case 'subjects':
        return 'subjects';
      case 'Student notices':
        return 'notification_cards';
      case 'Teacher notices':
        return 'notification_cards';
      case 'Schedules':
        return 'schedules';
      case 'Statistics': // أضف هذا السطر
        return 'statistics'; // أو 'home' حسب ما تستخدمه
      default:
        return label.toLowerCase().replaceAll(' ', '_');
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          width: sidebarWidth,
          padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 15),
          decoration: const BoxDecoration(
            color: AppColors.sidebar,
            boxShadow: [
              BoxShadow(
                color: Colors.black26,
                blurRadius: 8,
                offset: Offset(2, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              // زر الطي مع معلومات المستخدم
              /*  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  IconButton(
                    icon: Icon(
                      isCollapsed
                          ? Icons.arrow_forward_ios
                          : Icons.arrow_back_ios,
                      color: AppColors.background,
                    ),

                    onPressed: () => setState(() => isCollapsed = !isCollapsed),
                  ),
                  if (!isCollapsed) ...[
                    const SizedBox(width: 10),
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: AppColors.background,
                      child: Icon(
                        Icons.person,
                        size: 20,
                        color: AppColors.sidebar,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            "Administrator",
                            style: TextStyle(
                              color: AppColors.background,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            "University Ouargla",
                            style: TextStyle(
                              color: AppColors.background,
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),*/
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  if (!isCollapsed) ...[
                    const SizedBox(width: 10),
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: AppColors.background,
                      child: Icon(
                        Icons.person,
                        size: 20,
                        color: AppColors.sidebar,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            "Administrator",
                            style: TextStyle(
                              color: AppColors.background,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            "University Ouargla",
                            style: TextStyle(
                              color: AppColors.background,
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),

              const SizedBox(height: 20),

              // القائمة القابلة للتمرير
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      buildExpandableMenu("Home", Icons.home),
                      buildExpandableMenu(
                        "Admin",
                        Icons.admin_panel_settings,
                        children: ["Permissions", "Profile"],
                      ),
                      buildExpandableMenu(
                        "Teacher",
                        Icons.person,
                        children: ["Add Teacher", "Manage Teachers"],
                      ),
                      buildExpandableMenu(
                        "Student",
                        Icons.school,
                        children: ["Add Student", "Manage Students"],
                      ),
                      buildExpandableMenu(
                        "Class",
                        Icons.class_,
                        children: ["Groups", "Subjects"],
                        route: '/classes',
                      ),
                      buildMenuItem("Schedules", Icons.schedule),
                      buildMenuItem("Statistics", Icons.bar_chart),
                      //buildMenuItem("Notifications", Icons.notifications),
                      buildExpandableMenu(
                        "Notifications",
                        Icons.notifications,
                        children: ["Student notices", "Teacher notices"],
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),

              // زر الخروج دائمًا في الأسفل
              Align(
                alignment: Alignment.bottomCenter,
                child: buildLogoutButton(),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget buildCollapseButton() {
    return Align(
      alignment: Alignment.centerLeft,
      child: IconButton(
        icon: Icon(
          isCollapsed ? Icons.arrow_forward_ios : Icons.arrow_back_ios,
          color: AppColors.background,
        ),
        onPressed: () => setState(() => isCollapsed = !isCollapsed),
      ),
    );
  }

  Widget buildUserInfo() {
    return Column(
      children: [
        CircleAvatar(
          radius: 30,
          backgroundColor: AppColors.background,
          child: Icon(Icons.person, size: 30, color: AppColors.sidebar),
        ),
        if (!isCollapsed) ...[
          const SizedBox(height: 10),
          const Text(
            "Administrator",
            style: TextStyle(
              color: AppColors.background,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const Text(
            "University Ouargla",
            style: TextStyle(color: AppColors.background, fontSize: 12),
          ),
        ],
      ],
    );
  }

  Widget buildExpandableMenu(
    String label,
    IconData icon, {
    List<String> children = const [],
    String? route,
  }) {
    final isExpanded = expandedMenu == label;
    final isActive = activeMenu == label;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: () {
            setState(() {
              activeMenu = label;
              expandedMenu = isExpanded ? null : label;
            });
            // widget.onItemSelected(label); // <-- هذا هو السطر الجديد
            widget.onItemSelected(_normalizeLabel(label));
          },
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            decoration: BoxDecoration(
              color: isActive ? Colors.black26 : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                Icon(icon, color: AppColors.background),
                if (!isCollapsed) ...[
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      label,
                      style: const TextStyle(color: AppColors.background),
                    ),
                  ),
                  /* Icon(
                    isExpanded
                        ? Icons.keyboard_arrow_up
                        : Icons.keyboard_arrow_down,
                    color: AppColors.background,
                  ),*/
                  if (label != "Home")
                    Icon(
                      isExpanded
                          ? Icons.keyboard_arrow_up
                          : Icons.keyboard_arrow_down,
                      color: AppColors.background,
                    ),
                ],
              ],
            ),
          ),
        ),
        if (!isCollapsed && isExpanded)
          Padding(
            padding: const EdgeInsets.only(left: 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children:
                  /* children.map((subItem) {
                    return InkWell(
                      onTap: () {
                        setState(() => activeMenu = subItem);
                        widget.onItemSelected(_normalizeLabel(subItem)); // <-- إعلام الصفحة المختارة
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: Text(
                          "- $subItem",
                          style: const TextStyle(color: Colors.white70),
                        ),
                      ),
                    );
                  }).toList(),*/
                  children.map((subItem) {
                    final normalizedSubItem = _normalizeLabel(subItem);
                    final isSubItemActive =
                        _normalizeLabel(activeMenu) == normalizedSubItem;

                    return InkWell(
                      onTap: () {
                        setState(() => activeMenu = subItem);
                        widget.onItemSelected(normalizedSubItem);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          vertical: 6,
                          horizontal: 8,
                        ),
                        margin: const EdgeInsets.only(bottom: 4),
                        decoration: BoxDecoration(
                          color:
                              isSubItemActive
                                  ? Colors.white10
                                  : const Color.fromARGB(0, 3, 87, 7),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          "- $subItem",
                          style: TextStyle(
                            color:
                                isSubItemActive
                                    ? Colors.white
                                    : const Color.fromARGB(179, 255, 255, 255),
                            fontWeight:
                                isSubItemActive
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                            fontStyle:
                                isSubItemActive
                                    ? FontStyle.italic
                                    : FontStyle.normal,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
            ),
          ),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget buildMenuItem(String label, IconData icon) {
    //final isActive = activeMenu == label;
    final isActive = _normalizeLabel(activeMenu) == _normalizeLabel(label);

    return InkWell(
      onTap: () {
        setState(() {
          activeMenu = label;
          expandedMenu = null;
        });
        //widget.onItemSelected(label); // <-- تمرير الاختيار للوالد
        widget.onItemSelected(_normalizeLabel(label));
      },

      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          color: isActive ? Colors.black26 : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppColors.background),
            if (!isCollapsed) ...[
              const SizedBox(width: 10),
              Text(label, style: const TextStyle(color: AppColors.background)),
            ],
          ],
        ),
      ),
    );
  }

  Widget buildLogoutButton() {
    return ElevatedButton(
      onPressed: () {},
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.sidebar,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        padding:
            isCollapsed
                ? const EdgeInsets.all(8)
                : const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      ),
      child:
          isCollapsed
              ? const Icon(Icons.logout, size: 18)
              : ElevatedButton(
                onPressed: () async {
                  await FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => LoginScreen()),
                  );
                },
                child: const Text("Logout"),
              ),
      // : const Text("Logout"),
    );
  }
}
