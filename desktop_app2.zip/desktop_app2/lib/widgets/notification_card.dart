import 'package:flutter/material.dart';
import '../models/notification_model.dart';

class NotificationCard extends StatefulWidget {
  final NotificationModel notification;
  final VoidCallback onDelete;
  final VoidCallback? onMarkAsRead; // اختياري

  const NotificationCard({
    super.key,
    required this.notification,
    required this.onDelete,
    this.onMarkAsRead,
  });

  @override
  State<NotificationCard> createState() => _NotificationCardState();
}

class _NotificationCardState extends State<NotificationCard> {
  bool isRead = false;

  @override
  void initState() {
    super.initState();
    isRead = widget.notification.isRead ?? false; // دعم القيمة المبدئية
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      color: isRead ? Colors.grey[200] : Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: widget.notification.role == "Student"
              ? Colors.blueAccent
              : Colors.deepPurple,
          child: Icon(
            widget.notification.role == "Student" ? Icons.school : Icons.person,
            color: Colors.white,
          ),
        ),
        title: Text(
          widget.notification.sender,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.notification.message),
            const SizedBox(height: 4),
            Text(
              _formatTime(widget.notification.time),
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
        trailing: PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert),
          onSelected: (value) {
            if (value == 'delete') {
              widget.onDelete();
            } else if (value == 'mark_read') {
              setState(() {
                isRead = true;
              });
              widget.onMarkAsRead?.call();
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'mark_read',
              child: Text("Mark as read"),
            ),
            const PopupMenuItem(
              value: 'delete',
              child: Text("Delete"),
            ),
          ],
        ),
      ),
    );
  }

  String _formatTime(DateTime time) {
    final duration = DateTime.now().difference(time);
    if (duration.inMinutes < 60) {
      return "${duration.inMinutes} min ago";
    } else if (duration.inHours < 24) {
      return "${duration.inHours} h ago";
    } else {
      return "${duration.inDays} days ago";
    }
  }
}
