/*import 'package:flutter/material.dart';

enum StudentNotificationStatus { pending, accepted, rejected }

class StudentNotificationItem {
  final String studentName;
  final String requestType;
  final String reason;
  final DateTime date;
  final String subject;
  final String group;
  final String field;
  final String roomType;

  StudentNotificationStatus status;

  StudentNotificationItem({
    required this.studentName,
    required this.requestType,
    required this.reason,
    required this.date,
    required this.subject,
    required this.group,
    required this.field,
    required this.roomType,
    this.status = StudentNotificationStatus.pending,
  });
}

class StudentNoticesPage extends StatefulWidget {
  const StudentNoticesPage({super.key});

  @override
  State<StudentNoticesPage> createState() => _StudentNoticesPageState();
}

class _StudentNoticesPageState extends State<StudentNoticesPage> {
  List<StudentNotificationItem> notifications = [
    StudentNotificationItem(
      studentName: "أحمد يوسف",
      requestType: "تعديل توقيت",
      reason: "عندي تعارض مع مادة أخرى.",
      date: DateTime.now().subtract(const Duration(days: 1)),
      subject: "شبكات الحاسوب",
      group: "الفوج 1",
      field: "إعلام آلي معمق",
      roomType: "قاعة إعلام آلي عادية",
    ),
    StudentNotificationItem(
      studentName: "سارة بن علي",
      requestType: "طلب تعويض",
      reason: "تغيبت لأسباب صحية وأرغب في تعويض الحصة.",
      date: DateTime.now().subtract(const Duration(hours: 6)),
      subject: "برمجة كائنية",
      group: "الفوج 3",
      field: "إعلام آلي عادي",
      roomType: "قاعة إعلام آلي مخبر",
    ),
  ];

  StudentNotificationStatus? filter;

  void showStudentNotificationDialog(StudentNotificationItem notification) {
    final TextEditingController rejectReasonController =
        TextEditingController();
    bool showRejectReason = false;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              title: Text('طلب من ${notification.studentName}'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('📘 النوع: ${notification.requestType}'),
                  Text('📅 التاريخ: ${notification.date.toLocal()}'),
                  Text('🏫 نوع القاعة: ${notification.roomType}'),
                  const SizedBox(height: 12),
                  Text('📚 المادة: ${notification.subject}'),
                  Text('👥 الفوج: ${notification.group}'),
                  Text('🎓 التخصص: ${notification.field}'),
                  const SizedBox(height: 12),
                  Text('📝 السبب:\n${notification.reason}'),
                  if (showRejectReason)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: TextField(
                        controller: rejectReasonController,
                        decoration: const InputDecoration(
                          labelText: 'سبب الرفض',
                          border: OutlineInputBorder(),
                        ),
                        maxLines: 3,
                      ),
                    ),
                ],
              ),
              actions: [
                if (!showRejectReason)
                  TextButton(
                    onPressed: () {
                      setStateDialog(() => showRejectReason = true);
                    },
                    child: const Text(
                      'رفض',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      notification.status = StudentNotificationStatus.accepted;
                    });
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('تم قبول الطلب ✅')),
                    );
                  },
                  child: const Text(
                    'قبول',
                    style: TextStyle(color: Colors.green),
                  ),
                ),
                if (showRejectReason)
                  TextButton(
                    onPressed: () {
                      if (rejectReasonController.text.trim().isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('يرجى كتابة سبب الرفض')),
                        );
                        return;
                      }
                      setState(() {
                        notification.status =
                            StudentNotificationStatus.rejected;
                      });
                      Navigator.of(context).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'تم رفض الطلب مع السبب: ${rejectReasonController.text}',
                          ),
                        ),
                      );
                    },
                    child: const Text(
                      'تأكيد الرفض',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
              ],
            );
          },
        );
      },
    );
  }

  Icon _getStatusIcon(StudentNotificationStatus status) {
    switch (status) {
      case StudentNotificationStatus.accepted:
        return const Icon(Icons.check_circle, color: Colors.green);
      case StudentNotificationStatus.rejected:
        return const Icon(Icons.cancel, color: Colors.red);
      case StudentNotificationStatus.pending:
      default:
        return const Icon(Icons.hourglass_empty, color: Colors.orange);
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered =
        filter == null
            ? notifications
            : notifications.where((n) => n.status == filter).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "📢 إشعارات الطلبة",
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text("تصفية حسب الحالة: "),
              const SizedBox(width: 10),
              DropdownButton<StudentNotificationStatus?>(
                value: filter,
                items: const [
                  DropdownMenuItem(value: null, child: Text("الكل")),
                  DropdownMenuItem(
                    value: StudentNotificationStatus.pending,
                    child: Text("معلق"),
                  ),
                  DropdownMenuItem(
                    value: StudentNotificationStatus.accepted,
                    child: Text("مقبول"),
                  ),
                  DropdownMenuItem(
                    value: StudentNotificationStatus.rejected,
                    child: Text("مرفوض"),
                  ),
                ],
                onChanged: (value) {
                  setState(() => filter = value);
                },
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.delete_forever, color: Colors.red),
                tooltip: 'حذف كل الإشعارات',
                onPressed: () {
                  if (notifications.isEmpty) return;
                  showDialog(
                    context: context,
                    builder:
                        (_) => AlertDialog(
                          title: const Text("تأكيد الحذف"),
                          content: const Text(
                            "هل أنت متأكد أنك تريد حذف كل الإشعارات؟",
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text("إلغاء"),
                            ),
                            TextButton(
                              onPressed: () {
                                setState(() => notifications.clear());
                                Navigator.pop(context);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text("تم حذف كل الإشعارات"),
                                  ),
                                );
                              },
                              child: const Text(
                                "حذف",
                                style: TextStyle(color: Colors.red),
                              ),
                            ),
                          ],
                        ),
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 20),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: filtered.length,
            itemBuilder: (context, index) {
              final notif = filtered[index];
              return Card(
                elevation: 4,
                margin: const EdgeInsets.symmetric(vertical: 8),
                child: ListTile(
                  leading: _getStatusIcon(notif.status),
                  title: Text("${notif.studentName} - ${notif.requestType}"),
                  subtitle: Text(
                    notif.reason,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "${notif.date.day}/${notif.date.month}/${notif.date.year}",
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        tooltip: "حذف هذا الإشعار",
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder:
                                (_) => AlertDialog(
                                  title: const Text("تأكيد الحذف"),
                                  content: const Text(
                                    "هل أنت متأكد أنك تريد حذف هذا الإشعار؟",
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () => Navigator.pop(context),
                                      child: const Text("إلغاء"),
                                    ),
                                    TextButton(
                                      onPressed: () {
                                        setState(
                                          () => notifications.removeAt(index),
                                        );
                                        Navigator.pop(context);
                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          const SnackBar(
                                            content: Text("تم حذف الإشعار"),
                                          ),
                                        );
                                      },
                                      child: const Text(
                                        "حذف",
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    ),
                                  ],
                                ),
                          );
                        },
                      ),

                      /*IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        tooltip: "حذف هذا الإشعار",
                        onPressed: () {
                          setState(() => notifications.removeAt(index));
                        },
                      ),*/
                    ],
                  ),
                  onTap: () => showStudentNotificationDialog(notif),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
بلعربية
*/

import 'package:flutter/material.dart';

enum StudentNotificationStatus { pending, accepted, rejected }

class StudentNotificationItem {
  final String studentName;
  final String requestType;
  final String reason;
  final DateTime date;
  final String subject;
  final String group;
  final String field;
  final String roomType;

  StudentNotificationStatus status;

  StudentNotificationItem({
    required this.studentName,
    required this.requestType,
    required this.reason,
    required this.date,
    required this.subject,
    required this.group,
    required this.field,
    required this.roomType,
    this.status = StudentNotificationStatus.pending,
  });
}

class StudentNoticesPage extends StatefulWidget {
  const StudentNoticesPage({super.key});

  @override
  State<StudentNoticesPage> createState() => _StudentNoticesPageState();
}

class _StudentNoticesPageState extends State<StudentNoticesPage> {
  List<StudentNotificationItem> notifications = [
    StudentNotificationItem(
      studentName: "Ahmed Youssef",
      requestType: "Schedule Change",
      reason: "I have a conflict with another subject.",
      date: DateTime.now().subtract(const Duration(days: 1)),
      subject: "Computer Networks",
      group: "Group 1",
      field: "Advanced Computer Science",
      roomType: "Standard Computer Lab",
    ),
    StudentNotificationItem(
      studentName: "Sarah Ben Ali",
      requestType: "Make-up Request",
      reason: "I was absent for health reasons and would like to make up the session.",
      date: DateTime.now().subtract(const Duration(hours: 6)),
      subject: "Object-Oriented Programming",
      group: "Group 3",
      field: "General Computer Science",
      roomType: "Specialized Lab",
    ),
  ];

  StudentNotificationStatus? filter;

  void showStudentNotificationDialog(StudentNotificationItem notification) {
    final TextEditingController rejectReasonController = TextEditingController();
    bool showRejectReason = false;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              title: Text('Request from ${notification.studentName}'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('📘 Type: ${notification.requestType}'),
                  Text('📅 Date: ${notification.date.toLocal()}'),
                  Text('🏫 Room Type: ${notification.roomType}'),
                  const SizedBox(height: 12),
                  Text('📚 Subject: ${notification.subject}'),
                  Text('👥 Group: ${notification.group}'),
                  Text('🎓 Field: ${notification.field}'),
                  const SizedBox(height: 12),
                  Text('📝 Reason:\n${notification.reason}'),
                  if (showRejectReason)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: TextField(
                        controller: rejectReasonController,
                        decoration: const InputDecoration(
                          labelText: 'Rejection Reason',
                          border: OutlineInputBorder(),
                        ),
                        maxLines: 3,
                      ),
                    ),
                ],
              ),
              actions: [
                if (!showRejectReason)
                  TextButton(
                    onPressed: () {
                      setStateDialog(() => showRejectReason = true);
                    },
                    child: const Text(
                      'Reject',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      notification.status = StudentNotificationStatus.accepted;
                    });
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Request accepted ✅')),
                    );
                  },
                  child: const Text(
                    'Accept',
                    style: TextStyle(color: Colors.green),
                  ),
                ),
                if (showRejectReason)
                  TextButton(
                    onPressed: () {
                      if (rejectReasonController.text.trim().isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Please enter a rejection reason')),
                        );
                        return;
                      }
                      setState(() {
                        notification.status = StudentNotificationStatus.rejected;
                      });
                      Navigator.of(context).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Request rejected with reason: ${rejectReasonController.text}',
                          ),
                        ),
                      );
                    },
                    child: const Text(
                      'Confirm Rejection',
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
              ],
            );
          },
        );
      },
    );
  }

  Icon _getStatusIcon(StudentNotificationStatus status) {
    switch (status) {
      case StudentNotificationStatus.accepted:
        return const Icon(Icons.check_circle, color: Colors.green);
      case StudentNotificationStatus.rejected:
        return const Icon(Icons.cancel, color: Colors.red);
      case StudentNotificationStatus.pending:
      default:
        return const Icon(Icons.hourglass_empty, color: Colors.orange);
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = filter == null
        ? notifications
        : notifications.where((n) => n.status == filter).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "📢 Student Notifications",
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text("Filter by status: "),
              const SizedBox(width: 10),
              DropdownButton<StudentNotificationStatus?>(
                value: filter,
                items: const [
                  DropdownMenuItem(value: null, child: Text("All")),
                  DropdownMenuItem(
                    value: StudentNotificationStatus.pending,
                    child: Text("Pending"),
                  ),
                  DropdownMenuItem(
                    value: StudentNotificationStatus.accepted,
                    child: Text("Accepted"),
                  ),
                  DropdownMenuItem(
                    value: StudentNotificationStatus.rejected,
                    child: Text("Rejected"),
                  ),
                ],
                onChanged: (value) {
                  setState(() => filter = value);
                },
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.delete_forever, color: Colors.red),
                tooltip: 'Delete all notifications',
                onPressed: () {
                  if (notifications.isEmpty) return;
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text("Confirm Deletion"),
                      content: const Text(
                        "Are you sure you want to delete all notifications?",
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text("Cancel"),
                        ),
                        TextButton(
                          onPressed: () {
                            setState(() => notifications.clear());
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("All notifications deleted"),
                              ),
                            );
                          },
                          child: const Text(
                            "Delete",
                            style: TextStyle(color: Colors.red),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 20),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: filtered.length,
            itemBuilder: (context, index) {
              final notif = filtered[index];
              return Card(
                elevation: 4,
                margin: const EdgeInsets.symmetric(vertical: 8),
                child: ListTile(
                  leading: _getStatusIcon(notif.status),
                  title: Text("${notif.studentName} - ${notif.requestType}"),
                  subtitle: Text(
                    notif.reason,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "${notif.date.day}/${notif.date.month}/${notif.date.year}",
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        tooltip: "Delete this notification",
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text("Confirm Deletion"),
                              content: const Text(
                                "Are you sure you want to delete this notification?",
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context),
                                  child: const Text("Cancel"),
                                ),
                                TextButton(
                                  onPressed: () {
                                    setState(() => notifications.removeAt(index));
                                    Navigator.pop(context);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text("Notification deleted"),
                                      ),
                                    );
                                  },
                                  child: const Text(
                                    "Delete",
                                    style: TextStyle(color: Colors.red),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                  onTap: () => showStudentNotificationDialog(notif),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
