/*import 'package:desktop_app2/constants/colors.dart';
import 'package:flutter/material.dart';

class DashboardHeader extends StatelessWidget {
  const DashboardHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // العنوان + صورة المستخدم
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              "COLLEGE OF FNTIC  ",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            Row(
              children: [
                const Text(
                  "Walid Laribi",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: AppColors.primary),
                ),
                const SizedBox(width: 10),
                CircleAvatar(
                  radius: 22,
                  backgroundColor: AppColors.primary,
                  child: const Icon(Icons.person, color: Colors.white),
                ),
                const SizedBox(width: 10),
              ],
            )
          ],
        ),
        const SizedBox(height: 10),
        const Divider(thickness: 1.5),
      ],
    );
  }
}
//قبل اضافة responsive
*/

import 'package:desktop_app2/constants/colors.dart';
import 'package:desktop_app2/util/responsive.dart';
import 'package:flutter/material.dart';

class DashboardHeader extends StatelessWidget {
  const DashboardHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // العنوان + زر القائمة + المستخدم
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                // زر القائمة يظهر فقط إذا لم تكن الشاشة Desktop
                if (!Responsive.isDesktop(context))
                  Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: InkWell(
                      onTap: () => Scaffold.of(context).openDrawer(),
                      child: const Icon(Icons.menu, color: Colors.grey, size: 25),
                    ),
                  ),
                const Text(
                  "COLLEGE OF FNTIC",
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            Row(
              children: [
                const Text(
                  "Walid Laribi",//--------------------------------------------------------------------------------------------------
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: AppColors.primary,
                  ),
                ),
                const SizedBox(width: 10),
                CircleAvatar(
                  radius: 22,
                  backgroundColor: AppColors.primary,
                  child: const Icon(Icons.person, color: Colors.white),
                ),
                const SizedBox(width: 10),
              ],
            )
          ],
        ),
        const SizedBox(height: 10),
        const Divider(thickness: 1.5),
      ],
    );
  }
}
