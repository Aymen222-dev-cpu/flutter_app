class NotificationModel {
  final String sender;
  final String role;
  final String message;
  final DateTime time;
  final bool? isRead;

  NotificationModel({
    required this.sender,
    required this.role,
    required this.message,
    required this.time,
    this.isRead,
  });
}
