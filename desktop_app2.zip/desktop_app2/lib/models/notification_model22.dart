class NotificationModelnew {
  final String sender;
  final String role; // طالب أو أستاذ
  final String message;
  final DateTime time;

  NotificationModelnew({
    required this.sender,
    required this.role,
    required this.message,
    required this.time,
  });
}
