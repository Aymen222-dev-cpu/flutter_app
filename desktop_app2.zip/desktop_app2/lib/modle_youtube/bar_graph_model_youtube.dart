
import 'package:desktop_app2/modle_youtube/graph_model_youtube.dart';
import 'package:flutter/widgets.dart';

class BarGraphModel {
  final String label;
  final Color color;
  final List<GraphModel> graph;

  const BarGraphModel(
    {required this.label, required this.color, required this.graph});
}