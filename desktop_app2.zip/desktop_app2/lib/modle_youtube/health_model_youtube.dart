
class HealthModel {
  final String value;
  final String title;

  const HealthModel(
    {required this.value, required this.title});

}
