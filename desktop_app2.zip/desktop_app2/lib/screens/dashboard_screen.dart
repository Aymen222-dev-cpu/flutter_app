/*import 'package:desktop_app2/widgets/dashboard_header.dart';
import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/stat_card.dart';
import '../widgets/professor_form.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          const Sidebar(),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: const [
    DashboardHeader(),   // ← الهيدر هنا
    SizedBox(height: 1),

    // كروت الإحصائيات
    Row(
      children: [
        StatCard(
          icon: Icons.person,
          title: "Professors",
          value: "23",
          color: Colors.blueAccent,
        ),
        StatCard(
          icon: Icons.school,
          title: "Students",
          value: "145",
          color: Colors.green,
        ),
        StatCard(
          icon: Icons.schedule,
          title: "Classes",
          value: "12",
          color: Colors.orange,
        ),
        StatCard(
          icon: Icons.schedule,
          title: "Admins",
          value: "12",
          color: Colors.red,
        ),
      ],
    ),
    SizedBox(height: 20),

    // نموذج الإدخال
    ProfessorForm(),
  ],
),

            ),
          ),
        ],
      ),
    );
  }
} 
//قبل اضافة responsive
*/
// -----------------------------------------------------------------------------------------------------------------------------------
/*
import 'package:desktop_app2/util/responsive.dart';
import 'package:desktop_app2/widgets/dashboard_header.dart';
import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/stat_card.dart';
import '../widgets/professor_form.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final isDesktop = Responsive.isDesktop(context);

return Scaffold(
   drawer: Responsive.isMobile(context) ? const Sidebar() : null,
  body: Row(
    children: [
      // Sidebar يظهر فقط إذا لم تكن الشاشة موبايل
      if (!Responsive.isMobile(context)) const Sidebar(),

      // المحتوى الرئيسي
      Expanded(
         child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const DashboardHeader(),
              const SizedBox(height: 20),
              Wrap(
                spacing: 16,
                runSpacing: 16,
                children: const [
                  StatCard(
                    icon: Icons.person,
                    title: "Professors",
                    value: "23",
                    color: Colors.blueAccent,
                  ),
                  StatCard(
                    icon: Icons.school,
                    title: "Students",
                    value: "145",
                    color: Colors.green,
                  ),
                  StatCard(
                    icon: Icons.schedule,
                    title: "Classes",
                    value: "12",
                    color: Colors.orange,
                  ),
                  StatCard(
                    icon: Icons.schedule,
                    title: "Admins",
                    value: "12",
                    color: Colors.red,
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const ProfessorForm(),
            ],
          ),
        ),
      ),
      ),
    ],
  ),
);

  }
}
// قبل اضافة التنقل في الصفحات
*/

import 'package:desktop_app2/util/responsive.dart';
import 'package:desktop_app2/widgets/SchedulesPage.dart';
import 'package:desktop_app2/widgets/add_student_form.dart';
import 'package:desktop_app2/widgets/dashboard_header.dart';
import 'package:desktop_app2/widgets/groups_form.dart';
import 'package:desktop_app2/widgets/home_page.dart';
import 'package:desktop_app2/widgets/manage_student_form.dart';
import 'package:desktop_app2/widgets/manage_teacher_form.dart';
import 'package:desktop_app2/widgets/permissions_page.dart';
import 'package:desktop_app2/widgets/profile_form.dart';
import 'package:desktop_app2/widgets/statistics_page.dart';
import 'package:desktop_app2/widgets/student_notifications_form.dart';
import 'package:desktop_app2/widgets/subjects_fom.dart';
import 'package:desktop_app2/widgets/teacher_notifications_form.dart';
import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/stat_card.dart';
import '../widgets/professor_form.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  String selectedPage = 'dashboard'; // default page

  void updatePage(String page) {
    setState(() {
      selectedPage = page;
    });
    void updatePage(String page) {
      setState(() {
        selectedPage = page;
        print('Selected Page: $selectedPage'); // Debugging
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer:
          Responsive.isMobile(context)
              ? Sidebar(onItemSelected: updatePage)
              : null,
      body: Row(
        children: [
          if (!Responsive.isMobile(context))
            Sidebar(onItemSelected: updatePage),
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const DashboardHeader(),
                    const SizedBox(height: 20),
                    Wrap(
                      spacing: 16,
                      runSpacing: 16,
                      children: const [
                        StatCard(
                          icon: Icons.person,
                          title: "Professors",
                          value: "23",
                          color: Colors.blueAccent,
                        ),
                        StatCard(
                          icon: Icons.school,
                          title: "Students",
                          value: "145",
                          color: Colors.green,
                        ),
                        StatCard(
                          icon: Icons.class_outlined,
                          title: "Classes",
                          value: "12",
                          color: Colors.orange,
                        ),
                        StatCard(
                          icon: Icons.admin_panel_settings,
                          title: "Admins",
                          value: "12",
                          color: Colors.red,
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // المحتوى المتغير
                    if (selectedPage == 'dashboard') ...[
                      const HomePage(),
                    ] else if (selectedPage == 'home') ...[
                      const HomePage(),
                    ] else if (selectedPage == 'add_teacher') ...[
                      const ProfessorForm(),
                    ] else if (selectedPage == 'students') ...[
                      const Text("Students Page Here"),
                    ] else if (selectedPage == 'add_student') ...[
                      AddStudentForm(),
                    ] else if (selectedPage == 'manage_teachers') ...[
                      const ManageTeachersScreen(),
                    ] else if (selectedPage == 'manage_students') ...[
                      const ManageStudentsScreen(),
                    ] else if (selectedPage == 'groups') ...[
                      const GroupsManager(),
                    ] else if (selectedPage == 'subjects') ...[
                      const SubjectsManager(),
                    ] else if (selectedPage == 'student_notices') ...[
                      const StudentNoticesPage(),
                    ] else if (selectedPage == 'teacher_notices') ...[
                      const TeacherNoticesPage(),
                    ] else if (selectedPage == 'Profile_form') ...[
                      const ProfileForm(),
                    ] else if (selectedPage == 'schedules') ...[
                      const SchedulesPage(),
                    ] else if (selectedPage == 'permissions_page') ...[
                      const PermissionsPage(),
                    ] else if (selectedPage == 'statistics') ...[
                      const StatisticsPage(),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
