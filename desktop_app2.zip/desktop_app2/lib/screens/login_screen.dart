import 'package:flutter/material.dart';
import '../constants/colors.dart';
import '../widgets/login_form.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Center(
        child: Stack(
          children: [
            const Positioned(
              top: 40,
              left: 30,
              child: Text(
                "COLLEGE OF FNTIC",
                style: TextStyle(
                  fontSize: 25,
                  fontStyle: FontStyle.italic,
                  color: AppColors.primary,
                  shadows: [Shadow(color: Colors.grey, blurRadius: 6)],
                ),
              ),
            ),
            Center(
              child: Container(
                width: 300,
                padding: const EdgeInsets.all(30),
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 10,
                      offset: Offset(12, 12),
                    ),
                  ],
                ),
                child: const LoginForm(),
              ),
            ),
            /* const Positioned(
              bottom: 50,
              right: 30,
              child: Text(
                "welcome to your university",
                style: TextStyle(fontSize: 12),
              ),
            ),*/
            const Positioned(
              bottom: 50,
              right: 30,
              child: Text(
                "welcome to your university",
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
