/*import 'package:desktop_app2/constants/colors.dart';
import 'package:desktop_app2/screens/main_screen_youtube.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dashbord UI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor:AppColors.background2,
        brightness: Brightness.dark,
      ),
      home: MainScreen(),
    );
  }
}
// youtupe
*/
// ...............................................................................................................

import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: "AIzaSyDtDM2jsP_SH_ZiYmyOxZNXcY091zo-izQ",
      authDomain: "projectapp6-aa31a.firebaseapp.com",
      projectId: "projectapp6-aa31a",
      storageBucket: "projectapp6-aa31a.firebasestorage.app",
      messagingSenderId: "942519026244",
      appId: "1:942519026244:web:5fc6ff0cbb4b5f50def211",
      measurementId: "G-NZHQYPM9WY", // هذا اختياري، حسب الحاجة
    ),
  );
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
 
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  void initState() {
    FirebaseAuth.instance.authStateChanges().listen((User? user) {
      if (user == null) {
        print(
          'User is currently signed out!********************************************',
        );
      } else {
        print(
          'User is signed in!***********************************************',
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginScreen(),
    );
  }
}
//تفعيل صفحة login

// ...............................................................................................................
/*

import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginScreen(),
    );
  }
}// صفحة login  */

// ...............................................................................................................
/*import 'package:flutter/material.dart';
import 'screens/dashboard_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: AdminDashboard(),
    );
  }
}

//صفحة اضافة استاذ   */
