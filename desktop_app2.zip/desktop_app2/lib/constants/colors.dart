import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Colors.white;
  static const Color background2 = Color.fromARGB(255, 23, 40, 70);
  static const Color primary = Color(0xFF50C2C9); // لون البطاقة
  static const Color black = Colors.black;
  static const Color shadow = Colors.grey;
  static const Color loginBox = Color(0xFF50C2C9); // نفس لون المربع الأخضر في الصورة
  static const Color sidebar = Color(0xFF2FB7B9);
  static const Color button = Color(0xFF00ACC1);
  static const Color text = Colors.black87;
}
